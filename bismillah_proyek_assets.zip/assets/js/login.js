
// Data pengguna disimpan di localStorage sebagai simulasi database JSON
const users = JSON.parse(localStorage.getItem('users')) || [
    { username: 'admin', password: 'admin123' },
    { username: 'user', password: 'user123' }
];
localStorage.setItem('users', JSON.stringify(users));

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            const isValidUser = users.some(user => user.username === username && user.password === password);
            
            if (isValidUser) {
                alert('Login berhasil!');
                window.location.href = 'home.html';
            } else {
                alert('Username atau password salah!');
            }
        });
    }
});
