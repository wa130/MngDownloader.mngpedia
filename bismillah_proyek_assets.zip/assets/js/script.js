
window.addEventListener("load", () => {
    const loadingOverlay = document.getElementById("loading-overlay");
    if (loadingOverlay) {
        loadingOverlay.style.display = "none";
    }
});

// Navigasi menggunakan tombol dengan id "gunakan"
const btnGunakan = document.getElementById("gunakan");
if (btnGunakan) {
    btnGunakan.addEventListener("click", () => {
        const loadingOverlay = document.getElementById("loading-overlay");
        loadingOverlay.style.display = "flex";
        setTimeout(() => window.location.href = 'login.html', 700);
    });
}
